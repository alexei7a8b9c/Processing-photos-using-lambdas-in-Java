package lessons.java.functions;

public interface ImageOperation {
    float[] execute(float[] rgb);
}
