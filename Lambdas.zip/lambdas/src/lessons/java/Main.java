package lessons.java;

import lessons.java.utils.ImageUtils;
import lessons.java.utils.RgbMaster;
import lessons.java.functions.FilterOperation;
import java.util.Scanner;
import java.awt.image.BufferedImage;


public class Main {
    public static void main(String[] args) throws Exception {

        int x;
        Scanner scanner = new Scanner(System.in);
        final BufferedImage image = ImageUtils.getImage("images/crab.png");
        final RgbMaster rgbMaster = new RgbMaster(image);

        System.out.println("Обработка фото с помощью лямбд: \n" +
                "Монохромный фильтр - введите 1\n"+
                "Красный фильтр - введите 2\n"+
                "Зеленый фильтр - введите 3\n"+
                "Синий фильтр - введите 4\n"+
                "Фильтр с применением сепии - введите 5\n");
        System.out.println("Введите команду: ");
        x = scanner.nextInt();

            if (x == 1) {
                rgbMaster.changeImage(FilterOperation::greyScale);
                ImageUtils.saveImage(rgbMaster.getImage(), "images/cloned_crab1.png");
                System.out.println("Фильтр применен успешно. Изображение сохранено images/cloned_crab1.png");
            }
           else if (x == 2) {
                rgbMaster.changeImage(FilterOperation::onlyRed);
                ImageUtils.saveImage(rgbMaster.getImage(), "images/cloned_crab2.png");
                System.out.println("Фильтр применен успешно. Изображение сохранено images/cloned_crab2.png");
           }
            else if (x == 3) {
                rgbMaster.changeImage(FilterOperation::onlyGreen);
                ImageUtils.saveImage(rgbMaster.getImage(), "images/cloned_crab3.png");
                System.out.println("Фильтр применен успешно. Изображение сохранено images/cloned_crab3.png");
            }
            else if (x == 4) {
                rgbMaster.changeImage(FilterOperation::onlyBlue);
                ImageUtils.saveImage(rgbMaster.getImage(), "images/cloned_crab4.png");
                System.out.println("Фильтр применен успешно. Изображение сохранено images/cloned_crab4.png");
            }
            else if (x == 5) {
                rgbMaster.changeImage(FilterOperation::sepia);
                ImageUtils.saveImage(rgbMaster.getImage(), "images/cloned_crab5.png");
                System.out.println("Фильтр применен успешно. Изображение сохранено images/cloned_crab5.png");
            }

        }
   }